import { FriendlyRobot } from "base/robot";

export class DirectMovement {

	private robot: FriendlyRobot;
	constructor(robot: FriendlyRobot) {
		this.robot = robot;
	}

	run() {
		// TODO: Do your skill here
	}
}